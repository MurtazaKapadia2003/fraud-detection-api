
from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np
import os

app = FastAPI(title="Fraud Detection API")

# Load model
model_path = os.path.join(os.path.dirname(__file__), "fraud_model.pkl")
try:
    model = joblib.load(model_path)
    print("Model loaded")
except:
    model = None
    print("Model not found")

class Transaction(BaseModel):
    V1: float = 0
    V2: float = 0
    V3: float = 0
    V4: float = 0
    V5: float = 0
    V6: float = 0
    V7: float = 0
    V8: float = 0
    V9: float = 0
    V10: float = 0
    V11: float = 0
    V12: float = 0
    V13: float = 0
    V14: float = 0
    V15: float = 0
    V16: float = 0
    V17: float = 0
    V18: float = 0
    V19: float = 0
    V20: float = 0
    V21: float = 0
    V22: float = 0
    V23: float = 0
    V24: float = 0
    V25: float = 0
    V26: float = 0
    V27: float = 0
    V28: float = 0
    Amount: float = 0
    Time: float = 0

@app.get("/")
def root():
    return {"message": "Fraud Detection API", "status": "running"}

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.post("/predict")
def predict(transaction: Transaction):
    if model is None:
        return {"error": "Model not loaded"}
    data = [list(transaction.dict().values())]
    pred = model.predict(data)
    prob = model.predict_proba(data)[0]
    return {
        "is_fraud": bool(pred[0]),
        "fraud_probability": round(float(prob[1]), 4)
    }
