# Fraud Detection API

## Live Demo
https://fraud-detection-api.onrender.com

## Endpoints
- GET / - API info
- GET /health - Health check
- POST /predict - Predict fraud